/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.
 
 [Previous: Practice expressing yourself](@previous)

# Practice Identifying other people's emotions
 - Note: A reminder to turn off "Enable Results" before running this code. Not doing so may affect the view's layout.
 
This part follows a quiz format where you select the correct option for the emotion of the face on the screen. Although this does not use the neural network, it is still useful practice for those who may not be able to identify emotions. Currently, the question bank is limited to six faces but more may be added trivially.
 
- Experiment: The below code sets the number of choices in the multiple choice question. You may modify it to a number from one (inclusive) to six (inclusive). (Default: 4)
 */
let numberOfChoices: Int = 4

//: - Important: Please do not modify this code
import Foundation
import PlaygroundSupport

PlaygroundPage.current.liveView = QuizViewController(numChoices: numberOfChoices)

/*:
When you are ready, please advance to the next page.
 
[Next up: Conclusion](@next)
*/

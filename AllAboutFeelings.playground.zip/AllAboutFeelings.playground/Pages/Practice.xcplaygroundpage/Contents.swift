/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.
 
 [Previous: Identify emotions](@previous)

# Practice expressing yourself
 - Note: A reminder to turn off "Enable Results" before running this code. Not doing so may result in reduced performance or a crash.
 
 The previous page shows that a neural network can identify facial expressions. However, it can also be used as a coach for practicing emotions, helping people get better at expressing themselves.
 
 To practice making different facial expressions, simply run the code below. Then, follow the instructions on the screen. If you get stuck, click on the "Hint" button, and you will be shown a detailed explanation for how to make the facial expression, as well as an image. Please note that the hint does not constitute expert advice. The code will run in full screen. Exit full screen by stopping the playground.
 
 - Experiment: You may modify the code below. This boolean controls whether the front camera (the one on the front of the device) or the rear camera (the one on the back of the device) will be used. Setting to **false** will use the rear camera, while setting to **true** (default) will use the front camera.
 */
let useFrontCamera: Bool = false

//: - Experiment: You may modify the code below. Setting this string to **nil** (default) means that you will practice all available emotions. Setting this string to a single emotion means that you will only be practicing that emotion. Available values: **nil**, **"angry"**, **"scared"**, **"happy"**, **"neutral"**, **"sad"**, **"surprised"**
let onlyExpression: String? = nil

//: - Important: Please do not modify the following code.
import UIKit
import PlaygroundSupport

PlaygroundPage.current.wantsFullScreenLiveView = true
PlaygroundPage.current.liveView = PracticeViewController(useFrontCamera: useFrontCamera, onlyExpression: onlyExpression)

/*:
When you are ready, please advance to the next page.
 
[Next up: Practice identifying other people's emotions](@next)

*Sometimes, the frames will not match up perfectly with the faces on the screen. This is due to an UI issue with Playgrounds. The backend will still identify faces perfectly.*
*/

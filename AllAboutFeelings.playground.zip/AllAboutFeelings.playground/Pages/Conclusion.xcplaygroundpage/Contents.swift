/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.
 
 [Previous: Practice Identifying other people's emotions](@previous)

 This marks the end of this Playground. Thank you for viewing All About Feelings.
 ![Logo](Logo.png)
 */

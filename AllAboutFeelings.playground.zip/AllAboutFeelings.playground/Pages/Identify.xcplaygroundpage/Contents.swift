/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.

 [Previous: Before you begin](@previous)

 # Identifying emotions
- Note: A reminder to turn off "Enable Results" before running this code. Not doing so may result in reduced performance or a crash.
 
 Being unable to identify emotions is a massive disadvantage in life. However, we can mitigate this disadvantage by using a custom neural network.
 
 This playground page identifies emotions using a custom-trained neural network. To do this, simply run the code below and point the camera at people. Faces will be automatically recognised and facial expressions will be automatically identified. The code will run in full screen. Exit full screen by stopping the playground.

 - Experiment: You may modify the code below. This boolean controls whether the front camera (the one on the front of the device) or the rear camera (the one on the back of the device) will be used. Setting to **false** (default) will use the rear camera, while setting to **true** will use the front camera.*/
let useFrontCamera: Bool = false

//: - Important: Please do not modify the following code.
import UIKit
import PlaygroundSupport

PlaygroundPage.current.wantsFullScreenLiveView = true
PlaygroundPage.current.liveView = IdentifyViewController(useFrontCamera: useFrontCamera)

/*:
When you are ready, please advance to the next page.
 
[Next up: Practice expressing yourself](@next)

*Sometimes, the frames will not match up perfectly with the faces on the screen. This is due to an UI issue with Playgrounds. The backend will still identify faces perfectly.*
 
*/

/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.

 # Welcome to All About Feelings!
 
 ![Logo](Logo.png)
 
 # Table of Contents
 
 - [Before you begin](Instructions)
 
 - [Identifying emotions](Identify)
 
 - [Practice expressing yourself](Practice)
 
 - [Practice identifying other people's emotions](Quiz)
 
 - [Conclusion](Conclusion)
 
 # About
 
 All About Feelings is a demonstration of how machine learning and neural networks can be used can help people get better at recognise emotions.
 
 # Preface
 Emotions are an essential part of human communication. However, some people are unable to identify other people's facial expressions or express themselves using facial expressions. For example, people with Asperger syndrome (a condition on the autism spectrum) have trouble recognising facial expressions as well as other contextual cues that signal emotions. All About Feelings aims to demonstrate that with machine learning and neural networks, tasks such as recognising facial expressions and practicing facial expressions can be packaged into an app, which can be used on the go to improve one's ability to recognise and display emotions.

 There is no code on this page. When you are ready, please advance to the next page.
 
 [Next up: Before you begin](@next)
 */

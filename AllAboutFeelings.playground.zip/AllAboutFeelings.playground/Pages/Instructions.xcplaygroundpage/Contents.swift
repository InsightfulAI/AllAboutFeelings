/*:
 Playground by Wenzheng Du. Submission for WWDC Swift Student Challenge 2020.
 
 [Previous: Welcome](@previous)

 # Before you begin
 
 - Important: Before you begin, please remember to do the following:
 
 * Rotate the iPad to "Landscape Right" orientation, with the USB-C/Lightning port facing the right.
 
 * Move to a space with a clutter-free background where your face will be evenly lit.
 
 * Remember to switch off the "Enable Results" option every time before running code. Not doing so may cause issues with the performance and stability of this playground.
 
 * Give camera permissions when prompted so the playground may function. The camera is used to identify facial expressions.
 
 Please follow these instructions for an optimal experience. You can run the code below for visuals that accompany the above instructions.

 - Important: Please do not modify this code. */
import UIKit
import PlaygroundSupport

PlaygroundPage.current.liveView = InstructionsViewController()

/*:
 When you are ready, please advance to the next page.
 
 [Next up: Identifying emotions](@next)
 */


import Foundation
import UIKit
import AVFoundation
import Vision
import Accelerate

public class InferenceView: UIView {
    
    private let frameName: String = "Frame.png"
    private let labelNames: [String] = ["AngryLabel.png", "DisgustedLabel.png", "ScaredLabel.png", "HappyLabel.png", "NeutralLabel.png", "SadLabel.png", "SurprisedLabel.png"]
    private let frameColors: [UIColor] = [
        UIColor(red: 198.0/255.0, green: 042.0/255.0, blue: 000.0/255.0, alpha: 1.0),
        UIColor(red: 144.0/255.0, green: 140.0/255.0, blue: 000.0/255.0, alpha: 1.0),
        UIColor(red: 000.0/255.0, green: 139.0/255.0, blue: 122.0/255.0, alpha: 1.0),
        UIColor(red: 008.0/255.0, green: 135.0/255.0, blue: 255.0/255.0, alpha: 1.0),
        UIColor(red: 106.0/255.0, green: 106.0/255.0, blue: 106.0/255.0, alpha: 1.0),
        UIColor(red: 020.0/255.0, green: 000.0/255.0, blue: 219.0/255.0, alpha: 1.0),
        UIColor(red: 185.0/255.0, green: 000.0/255.0, blue: 185.0/255.0, alpha: 1.0)
    ]
    private var frameImage: UIImage?
    private var labelImages: [UIImage] = []
    
    private var drawLabels: Bool = false
    private var singleFace: Bool = false
    
    private weak var previewLayer: AVCaptureVideoPreviewLayer?
    private var faces: [CIFeature] = []
    private var drawingFaces: [CGRect] = []
    let faceQueue = DispatchQueue(label: "faceQueue")
    private var expressions: [FaceModelOutput] = []
    
    private var isFrontCam: Bool = true
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public init(frame: CGRect, drawLabels: Bool, singleFace: Bool, isFrontCam: Bool) {
        super.init(frame: frame)
        autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.drawLabels = drawLabels
        self.singleFace = singleFace
        backgroundColor = .clear
        frameImage = UIImage(named: frameName)!
        var labelImages: [UIImage] = []
        for name in labelNames {
            labelImages.append(UIImage(named: name)!)
        }
        self.labelImages = labelImages
        self.isFrontCam = isFrontCam
    }
    
    public func getFaces() -> [CGRect] {
        faceQueue.sync {
            let duplicateFaces = drawingFaces
            return duplicateFaces
        }
    }
    
    public func getLargestFace() -> CGRect? {
        let index = getLargestIndex()
        var face: CGRect? = nil
        faceQueue.sync {
            face = index < drawingFaces.count ? drawingFaces[index] : nil
        }
        return face
    }
    
    public func getLargestFaceExpression() -> FaceModelOutput? {
        let index = getLargestIndex()
        var output: FaceModelOutput? = nil
        faceQueue.sync {
            output = index < expressions.count ? expressions[index] : nil
        }
        return output
    }
    
    public func getLargestIndex() -> Int {
        faceQueue.sync {
            var largestFace: CGRect? = nil
            var largestIndex: Int = 0
            for i in 0..<drawingFaces.count {
                let face = drawingFaces[i]
                if (largestFace == nil || largestFace!.width < face.width) {
                    largestFace = face
                    largestIndex = i
                }
            }
            return largestIndex
        }
    }
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)
        guard let context = UIGraphicsGetCurrentContext() else {
          return
        }
        context.setStrokeColor(gray: CGFloat(0.5), alpha: CGFloat(1.0))
        if (singleFace) {
            if let face = getLargestFace() {
                let expression = getLargestFaceExpression()
                drawFace(face: face, expression: drawLabels ? expression : nil, viewRect: rect)
            }
        } else {
            let duplicateFaces = getFaces()
            for i in 0..<duplicateFaces.count {
                let face = duplicateFaces[i]
                let expression = i < expressions.count ? expressions[i] : nil
                drawFace(face: face, expression: drawLabels ? expression : nil, viewRect: rect)
            }
        }
    }
    
    private func drawFace(face: CGRect, expression: FaceModelOutput?, viewRect: CGRect) {
        var labelImage: UIImage?
        var frameImage: UIImage = self.frameImage!
        if let faceExpression = expression {
            let classIndex = getClassIndexFromLabel(faceExpression.classLabel)
            labelImage = labelImages[classIndex]
            frameImage = frameImage.recolor(color: frameColors[classIndex])
        }
        let widescreenRect = toWidescreen(rect: viewRect)
        let rect = convert(rect: face, sourceRect: widescreenRect, scale: UIScreen.main.scale)
        
        
        let scaledViewRect = CGRect(x: viewRect.minX / UIScreen.main.scale, y: viewRect.minY / UIScreen.main.scale, width: viewRect.width / UIScreen.main.scale, height: viewRect.height / UIScreen.main.scale)
        let finalRect = processRect(in: rect, source: scaledViewRect, inverted: true)
        frameImage.draw(in: finalRect)
        if let label = labelImage {
            label.draw(in: finalRect)
        }
    }
    
    private func sortFaces(in faces: [VNFaceObservation]) -> [VNFaceObservation] {
        var duplicateFaces = faces
        var sorted: [VNFaceObservation] = []
        while duplicateFaces.count > 0 {
            var leftmostFace: VNFaceObservation? = nil
            var leftmostIndex: Int = 0
            for i in 0..<duplicateFaces.count {
                let face = faces[i]
                if (leftmostFace == nil || leftmostFace!.boundingBox.midX < face.boundingBox.midX) {
                    leftmostFace = face
                    leftmostIndex = i
                }
            }
            sorted.append(leftmostFace!)
            duplicateFaces.remove(at: leftmostIndex)
        }
        return sorted
    }

    private func detectFaces(ciImage: CIImage) -> [CIFeature] {
        let options = [CIDetectorAccuracy: CIDetectorAccuracyHigh]
        let faceDetector = CIDetector(ofType: CIDetectorTypeFace, context: nil, options: options)!
        let faces = faceDetector.features(in: ciImage)
        return faces
    }
    
    private func identifyEmotions(image: CIImage, faces: [CIFeature]) {
        var inputs: [FaceModelInput] = []
        if faces.isEmpty {
            return
        }
        for face: CIFeature in faces {
            let faceRect = face.bounds
            let finalRect = processRect(in: faceRect, source: image.extent, inverted: false)
            let croppedImage = image.cropped(to: finalRect)
            if let processed = preprocessInput(original: croppedImage) {
                inputs.append(FaceModelInput(input: processed))
            }
        }
        let model = FaceModel()
        
        guard let predictions = try? model.predictions(inputs: inputs) else {
            fatalError("Model prediction error")
        }
        expressions = predictions
    }
    
    private func convert(rect: CGRect, sourceRect: CGRect, scale: CGFloat) -> CGRect {
        let newOrigin = CGPoint(x: (rect.origin.x * sourceRect.width + sourceRect.origin.x) / scale, y: (rect.origin.y * sourceRect.height + sourceRect.origin.y) / scale)
        let newSize = CGSize(width: rect.width * sourceRect.width / scale, height: rect.height * sourceRect.height / scale)
        return CGRect(origin: newOrigin, size: newSize)
    }
    
    private func processRect(in original: CGRect, source: CGRect, inverted: Bool) -> CGRect {
        let faceSquare = toSquare(rect: original)
        let borderRatio = CGFloat(1.2)
        let scaledSquare = CGRect(x: faceSquare.midX - faceSquare.width * borderRatio / 2.0, y: faceSquare.midY - faceSquare.height * borderRatio / 2.0, width: faceSquare.width * borderRatio, height: faceSquare.height * borderRatio)
        let invertedSquare = CGRect(x: scaledSquare.minX, y: source.height - scaledSquare.maxY, width: scaledSquare.width, height: scaledSquare.height)
        if inverted {
            return invertedSquare
        }
        return scaledSquare
    }
    
    private func toSquare(rect: CGRect) -> CGRect {
        let maxSide = CGFloat.maximum(rect.width, rect.height)
        return CGRect(x: rect.midX - maxSide/2.0, y: rect.midY - maxSide/2.0, width: maxSide, height: maxSide)
    }
    
    private func toWidescreen(rect: CGRect) -> CGRect {
        let height = rect.width / 16.0 * 9.0
        //return CGRect(x: rect.minX, y: rect.midY - height/2.0, width: rect.width, height: height) // This code is for running on an app instead of a playground
        return CGRect(x: rect.minX, y: 0, width: rect.width, height: height) //Do not center the widescreen rect in the playground
    }
    
    private func preprocessInput(original: CIImage) -> CVPixelBuffer? {
        guard let cgImage: CGImage = CIContext(options: nil).createCGImage(original, from: original.extent) else{
            return nil
        } //Otherwise draws a blank screen
        let image = UIImage(cgImage: cgImage)
        let rect = CGRect(x: 0, y: 0, width: 48, height: 48)
        UIGraphicsBeginImageContextWithOptions(rect.size, true, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return toGrayscale(original: newImage!)!.toCVPixelBufferGrayscale()!
    }
    
    private func toGrayscale(original: UIImage) -> UIImage? {
        let cgImage: CGImage = original.cgImage!
        guard let rgbFormat = vImage_CGImageFormat(
            bitsPerComponent: cgImage.bitsPerComponent,
            bitsPerPixel: cgImage.bitsPerPixel,
            colorSpace: cgImage.colorSpace!,
            bitmapInfo: cgImage.bitmapInfo,
            renderingIntent: .defaultIntent) else {
                return nil
        }
        var imageBuffer: vImage_Buffer = try! vImage_Buffer(cgImage: cgImage, format: rgbFormat)
        let red: Float = 0.2126
        let green: Float = 0.7152
        let blue: Float = 0.0722

        
        let div: Int32 = 0x1000
        let fDiv = Float(div)

        var coefficientsMatrix = [Int16(red * fDiv), Int16(green * fDiv), Int16(blue * fDiv)]
        
        let preBias: [Int16] = [0, 0, 0, 0]
        let postBias: Int32 = 0
        
        var outputBuffer: vImage_Buffer = try! vImage_Buffer(width: cgImage.width, height: cgImage.height, bitsPerPixel: 8)

        vImageMatrixMultiply_ARGB8888ToPlanar8(&imageBuffer, &outputBuffer, &coefficientsMatrix, div, preBias, postBias, vImage_Flags(kvImageNoFlags))
        
        guard let monoFormat = vImage_CGImageFormat(
            bitsPerComponent: 8,
            bitsPerPixel: 8,
            colorSpace: CGColorSpaceCreateDeviceGray(),
            bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.none.rawValue),
            renderingIntent: .defaultIntent) else {
                return nil
        }
        
        return UIImage(cgImage: try! outputBuffer.createCGImage(format: monoFormat))
    }
    
    private func getClassIndexFromLabel(_ label: String) -> Int {
        switch label {
        case "angry":
            return 0
        case "disgusted":
            return 1
        case "scared":
            return 2
        case "happy":
            return 3
        case "neutral":
            return 4
        case "sad":
            return 5
        case "surprised":
            return 6
        default:
            return -1 // Error
        }
    }
}

extension InferenceView: AVCaptureVideoDataOutputSampleBufferDelegate {
    public func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer: CVPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        var ciImage: CIImage = CIImage(cvPixelBuffer: pixelBuffer)
        if (isFrontCam) {
            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: -1, y: 1)).transformed(by: CGAffineTransform(translationX: ciImage.extent.width, y: 0)) // Flips horizontally if needed
        }
        let faces: [CIFeature] = detectFaces(ciImage: ciImage)
        identifyEmotions(image: ciImage, faces: faces)
        faceQueue.sync {
            self.faces = faces
            var drawingFaces: [CGRect] = []
            for face in faces {
                drawingFaces.append(face.bounds.applying(CGAffineTransform(scaleX: 1.0/ciImage.extent.width, y: 1.0/ciImage.extent.height)))
                self.drawingFaces = drawingFaces
            }
        }
        DispatchQueue.main.async {
            self.setNeedsDisplay()
        }
    }
}

extension UIImage {
    func toCVPixelBufferGrayscale() -> CVPixelBuffer? {
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer : CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(self.size.width), Int(self.size.height), kCVPixelFormatType_OneComponent8, attrs, &pixelBuffer) // Convert to grayscale
        guard status == kCVReturnSuccess else {
            return nil
        }

        if let pixelBuffer = pixelBuffer {
            CVPixelBufferLockBaseAddress(pixelBuffer, CVPixelBufferLockFlags(rawValue: 0))
            let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer)

            let colorSpace = CGColorSpaceCreateDeviceGray() // Grayscale
            let context = CGContext(data: pixelData, width: Int(self.size.width), height: Int(self.size.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer), space: colorSpace, bitmapInfo: CGImageAlphaInfo.none.rawValue)

            context?.translateBy(x: 0, y: self.size.height)
            context?.scaleBy(x: 1.0, y: -1.0)

            UIGraphicsPushContext(context!)
            self.draw(in: CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height))
            UIGraphicsPopContext()
            CVPixelBufferUnlockBaseAddress(pixelBuffer, CVPixelBufferLockFlags(rawValue: 0))

            return pixelBuffer
        }

        return nil
    }
    
    public func pixelBufferGray(width: Int, height: Int) -> CVPixelBuffer? {

        var pixelBuffer : CVPixelBuffer?
        let attributes = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue]

        let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(width), Int(height), kCVPixelFormatType_OneComponent8, attributes as CFDictionary, &pixelBuffer)

        guard status == kCVReturnSuccess, let imageBuffer = pixelBuffer else {
            return nil
        }

        CVPixelBufferLockBaseAddress(imageBuffer, CVPixelBufferLockFlags(rawValue: 0))

        let imageData =  CVPixelBufferGetBaseAddress(imageBuffer)

        guard let context = CGContext(data: imageData, width: Int(width), height:Int(height),
                                      bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(imageBuffer),
                                      space: CGColorSpaceCreateDeviceGray(),
                                      bitmapInfo: CGImageAlphaInfo.none.rawValue) else {
                                        return nil
        }

        context.translateBy(x: 0, y: CGFloat(height))
        context.scaleBy(x: 1, y: -1)

        UIGraphicsPushContext(context)
        self.draw(in: CGRect(x:0, y:0, width: width, height: height) )
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(imageBuffer, CVPixelBufferLockFlags(rawValue: 0))

        return imageBuffer

    }
    
    func recolor(color: UIColor) -> UIImage{
        let ciImage = CIImage(image: self)
        let filter = CIFilter(name: "CIMultiplyCompositing")!

        let colorImage = CIImage(color: CIColor(color: color))

        filter.setValue(colorImage, forKey: kCIInputImageKey)
        filter.setValue(ciImage, forKey: kCIInputBackgroundImageKey)

        return UIImage(ciImage: filter.outputImage!)
    }
}


import Foundation
import UIKit

public class HintView: UIStackView {
    
    private let imageNames: [String] = ["AngryFace.jpg", "ScaredFace.jpg", "HappyFace.jpg", "NeutralFace.jpg", "SadFace.jpg", "SurprisedFace.jpg", ""]
    private let titles: [String] = ["Angry", "Scared", "Happy", "Neutral", "Sad", "Surprised", "Error"]
    private let descriptions: [String] = [
        "In an angry face, the eyebrows are in a frown, and the mouth is wide open with teeth visible. You can also express anger by tilting your head sideways or by giving a sideways glare.",
        "Fear is an useful emotion in a number of scenarios. If you\'re scared, then your eyes are wide open and your mouth is agape, although the opening will not be very large. Compared to surprise, the mouth is wider and shows teeth.",
        "To show you\'re happy, raise your cheeks into a smile. The corners of your mouth should be pointing up. Your eyes should also be a bit squinted.",
        "To make a neutral expression, close your mouth, relax your lips and your facial muscles, and look directly forward",
        "Sadness is one of the most difficult expressions to fake. However, you can also show it by tilting your head down and looking downwards.",
        "When you\'re surprised, your eyes are wide open and your mouth is also open. However, unlike fear, the mouth protrudes forwards and the teeth are not visible.",
        "An error has occured."
    ]
    private let additionalDescription: String = "\nIf you are making the correct expression and the prompt says \"Almost there\" then try moving your head around, varying the angle of your head and moving to a location with a different lighting."
    
    private weak var background: UIView?

    public required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public init(frame: CGRect, expressionIndex: Int, background: UIView) {
        super.init(frame: frame)
        self.background = background
        self.alignment = .fill
        self.axis = .vertical
        self.distribution = .fill
        let titleView = UILabel()
        titleView.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.height/8)
        titleView.text = titles[expressionIndex]
        titleView.font = titleView.font.withSize(24)
        titleView.textAlignment = .center
        titleView.textColor = .black
        self.addSubview(titleView)
        let imageView = UIImageView()
        imageView.frame = CGRect(x: 0, y: frame.height/8, width: frame.width, height: frame.height/4)
        imageView.image = UIImage(named: imageNames[expressionIndex])
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth]
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        self.addSubview(imageView)
        let descriptionView = UILabel()
        descriptionView.frame = CGRect(x: 0, y: frame.height*3/8, width: frame.width, height: frame.height/2)
        descriptionView.text = descriptions[expressionIndex]+additionalDescription
        descriptionView.numberOfLines = 0
        descriptionView.font = titleView.font.withSize(12)
        descriptionView.textAlignment = .justified
        descriptionView.textColor = .black
        self.addSubview(descriptionView)
        let closeButton = UIButton(type: .system)
        closeButton.frame = CGRect(x: 0, y: frame.height*7/8, width: frame.width, height: frame.height/8)
        closeButton.setTitle("Close", for: .normal)
        closeButton.titleLabel!.font = closeButton.titleLabel!.font.withSize(16)
        closeButton.addTarget(self, action: #selector(HintView.close(_:)), for: .touchUpInside)
        self.addSubview(closeButton)
    }
    
    @objc private func close(_ sender: UIButton) {
        background?.removeFromSuperview()
    }
    
}

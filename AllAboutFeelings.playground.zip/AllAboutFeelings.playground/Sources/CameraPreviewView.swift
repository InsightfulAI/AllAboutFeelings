import UIKit
import AVFoundation


public class CameraPreviewView: UIView {
    
    private var previewLayer: AVCaptureVideoPreviewLayer?
    public var inferenceView: InferenceView?
    private var useFrontCamera: Bool = true
    private var drawLabels: Bool = true
    private var singleFace: Bool = false
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public init(frame: CGRect, drawLabels: Bool, singleFace: Bool) {
        super.init(frame: frame)
        self.drawLabels = drawLabels
        self.singleFace = singleFace
    }
    
    public override convenience init(frame: CGRect) {
        self.init(frame: frame, drawLabels: true, singleFace: false)
    }
    
    // MARK: Public Methods
    public func setup(useFrontCamera: Bool) {
        self.useFrontCamera = useFrontCamera
        setupCaptureSession(useFrontCamera: useFrontCamera)
        updateOrientation()
    }
    
    public func getOrientation() -> AVCaptureVideoOrientation {
        // Unfortunately, there is currently no way of getting the orientation of a Swift playground
        /*let orientation: UIDeviceOrientation = UIDevice.current.orientation
        switch orientation{
        case .portrait:
            return AVCaptureVideoOrientation.portrait
        case .portraitUpsideDown:
            return AVCaptureVideoOrientation.portraitUpsideDown
        case .landscapeLeft:
            return AVCaptureVideoOrientation.landscapeLeft
        case .landscapeRight:
            return AVCaptureVideoOrientation.landscapeRight
        default:
            print("Unexpected orientation: \(orientation)")
            return AVCaptureVideoOrientation.portrait
        }*/
        return AVCaptureVideoOrientation.landscapeRight
    }
    
    public func updateOrientation() {
        previewLayer?.connection?.videoOrientation = getOrientation()
        previewLayer?.session?.outputs.forEach {
            $0.connections.forEach {
                $0.videoOrientation = getOrientation()
            }
        }
    }
    
    // MARK: Private Methods
    private func setupCaptureSession(useFrontCamera: Bool) {
        let captureSession = AVCaptureSession()
        
        
        do {
            if let device = getDevice(front: useFrontCamera) {
                captureSession.addInput(try AVCaptureDeviceInput(device: device))
            } else {
                print("Camera unavailable.")
            }
        } catch {
            print("Camera unavailable.")
        }
        
        
        //Setup video and add to screen
        let captureOutput = AVCaptureVideoDataOutput()
        captureSession.addOutput(captureOutput)
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        self.previewLayer = previewLayer
        previewLayer.videoGravity = .resizeAspect
        previewLayer.frame = frame
        
        layer.addSublayer(previewLayer)
        
        setupInferenceView(captureOutput: captureOutput)
        captureSession.startRunning()
    }
    
    private func getDevice(front: Bool = true) -> AVCaptureDevice? {
        //Get available cameras
        var availableDevices: [AVCaptureDevice] = []
        if front {
            availableDevices = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera, .builtInDualCamera, .builtInTrueDepthCamera], mediaType: AVMediaType.video, position: .front).devices
        } else {
            availableDevices = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera, .builtInDualCamera, .builtInTrueDepthCamera], mediaType: AVMediaType.video, position: .back).devices
        }
        //Select a camera
        if let captureDevice = availableDevices.first {
            return captureDevice
        } else {
            return nil
        }
    }
    
    private func setupInferenceView(captureOutput: AVCaptureVideoDataOutput) {
        let inferenceView = InferenceView(frame: self.frame, drawLabels: drawLabels, singleFace: singleFace, isFrontCam: useFrontCamera)
        self.inferenceView = inferenceView
        
        captureOutput.setSampleBufferDelegate(inferenceView, queue: DispatchQueue(label: "videoQueue"))
        addSubview(inferenceView)
    }
    
}

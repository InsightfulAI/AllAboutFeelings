
//
//  IdentifyViewController.swift
//
//
//  Created by Wenzheng Du on 8/5/20.
//
import UIKit
import AVFoundation


public class PracticeViewController: UIViewController {
    
    private static let prepareText = "Make this expression: "
    
    private static let allExpressions = ["angry", "scared", "happy", "neutral", "sad", "surprised"]
    
    private var useFrontCamera: Bool = true
    private var cameraPreviewView: CameraPreviewView?
    private var onlyExpression: String? = nil
    
    private var headerView: UIView!
    private var headerText: UILabel!
    private var currentExpression: String = ""
    
    public convenience init(useFrontCamera: Bool, onlyExpression: String? = nil) {
        self.init()
        self.useFrontCamera = useFrontCamera
        self.onlyExpression = onlyExpression
    }
    
    public override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        self.view = view
        setupHeader()
    }
    
    public override func viewDidLoad() {
        let cameraPreviewView = CameraPreviewView(frame: UIScreen.main.bounds, drawLabels: false, singleFace: true)
        cameraPreviewView.backgroundColor = .black
        cameraPreviewView.setup(useFrontCamera: useFrontCamera)
        cameraPreviewView.translatesAutoresizingMaskIntoConstraints = false
        cameraPreviewView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.cameraPreviewView = cameraPreviewView
        self.view.addSubview(cameraPreviewView)
        setupHeader()
        setupHint()
        DispatchQueue.global(qos: .userInteractive).async {
            self.startPractice()
        }
    }
    
    public override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        cameraPreviewView?.updateOrientation()
    }
    
    private func setupHeader() {
        let header = UIView()
        header.frame = CGRect(x: 0, y: 0, width: 0, height: 100)
        header.backgroundColor = .systemBlue
        header.autoresizingMask = [.flexibleWidth]
        view.addSubview(header)
        self.headerView = header
        let text = UILabel()
        text.frame = CGRect(x: 0, y: 0, width: 0, height: 100)
        text.textColor = .black
        text.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        text.textAlignment = .center
        text.font = text.font.withSize(36)
        header.addSubview(text)
        self.headerText = text
    }
    
    private func setupHint() {
        let hintButton: UIButton = UIButton(type: .custom)
        hintButton.frame = CGRect(x: self.view.frame.minX + 32, y: self.view.frame.minY + 110, width: 100, height: 100)
        hintButton.imageView?.contentMode = .scaleAspectFit
        hintButton.setImage(UIImage(named: "Hint.png"), for: .normal)
        hintButton.addTarget(self, action: #selector(PracticeViewController.startHint(_:)), for: .touchUpInside)
        self.view.addSubview(hintButton)
    }
    
    @objc private func startHint(_ sender: UIButton) {
        let frame = CGRect(x: self.view.frame.minX, y: self.view.frame.minY + 100, width: self.view.frame.width/3.0, height: self.view.frame.height - 100)
        let backgroundView = UIView(frame: frame)
        backgroundView.backgroundColor = .white
        let hintView = HintView(frame: CGRect(x: 16, y: 16, width: frame.width - 32, height: frame.height - 32), expressionIndex: PracticeViewController.allExpressions.firstIndex(of: currentExpression) ?? 7, background: backgroundView)
        backgroundView.addSubview(hintView)
        self.view.addSubview(backgroundView)
    }
    
    private func startPractice() {
        if let expression = onlyExpression {
            currentExpression = expression
        } else {
            currentExpression = PracticeViewController.allExpressions.randomElement()!
        }
        DispatchQueue.main.async {
            self.headerView.backgroundColor = .systemBlue
            self.headerText.text = PracticeViewController.prepareText + self.currentExpression + "."
        }
        countdown(seconds: 4)
    }
    
    private func countdown(seconds: Int) {
        var currentSeconds = seconds
        while currentSeconds > 0 {
            DispatchQueue.main.async {
                self.headerText.text = PracticeViewController.prepareText + self.currentExpression + "." + " In \(currentSeconds)"
                if (currentSeconds == 0) {
                    self.headerText.text = PracticeViewController.prepareText + self.currentExpression + "." + " GO!"
                }
            }
            currentSeconds -= 1
            Thread.sleep(forTimeInterval: 1.0)
        }
        duringPractice()
    }
    
    private func duringPractice() {
        if let inferenceView = cameraPreviewView?.inferenceView {
            while (inferenceView.getLargestFaceExpression()?.classLabel != currentExpression) {
                if let cameraExpression = inferenceView.getLargestFaceExpression() {
                    let prob = cameraExpression.output[currentExpression]!
                    DispatchQueue.main.async {
                        if prob >= 0.05 {
                            self.headerText.text = PracticeViewController.prepareText + self.currentExpression + "." + " Almost there!"
                        } else {
                            self.headerText.text = PracticeViewController.prepareText + self.currentExpression + "."
                        }
                    }
                }
                Thread.sleep(forTimeInterval: 1.0/60.0)
            }
            success()
        }
    }
    
    private func success() {
        DispatchQueue.main.async {
            self.headerView.backgroundColor = .systemGreen
            self.headerText.text = "Perfect! "
        }
        Thread.sleep(forTimeInterval: 2.0)
        startPractice()
    }
}

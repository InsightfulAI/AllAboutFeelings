import Foundation
import UIKit

public class InstructionsViewController: UIViewController {
    
    private weak var landscape: UIImageView!
    private weak var clutter: UIImageView!
    private weak var performance: UIImageView!
    private weak var camera: UIImageView!
    
    public override func loadView() {
        let background = UIView()
        background.backgroundColor = .white
        self.view = background
        let landscape = UIImageView()
        landscape.image = UIImage(named: "Landscape.png")
        landscape.contentMode = .scaleAspectFit
        self.landscape = landscape
        self.view.addSubview(landscape)
        let clutter = UIImageView()
        clutter.image = UIImage(named: "Clutter.png")
        clutter.contentMode = .scaleAspectFit
        self.clutter = clutter
        self.view.addSubview(clutter)
        let performance = UIImageView()
        performance.image = UIImage(named: "Performance.png")
        performance.contentMode = .scaleAspectFit
        self.performance = performance
        self.view.addSubview(performance)
        let camera = UIImageView()
        camera.image = UIImage(named: "Camera.png")
        camera.contentMode = .scaleAspectFit
        self.camera = camera
        self.view.addSubview(camera)
    }
    
    public override func viewDidLayoutSubviews() {
        let frame = self.view.frame
        //Update the size of the images
        landscape.frame = CGRect(x: 16, y: 16, width: frame.width/2 - 32, height: frame.height/2 - 32)
        clutter.frame = CGRect(x: 16 + frame.width/2, y: 16, width: frame.width/2 - 32, height: frame.height/2 - 32)
        performance.frame = CGRect(x: 16, y: 16 + frame.height/2, width: frame.width/2 - 32, height: frame.height/2 - 32)
        camera.frame = CGRect(x: 16 + frame.width/2, y: 16 + frame.height/2, width: frame.width/2 - 32, height: frame.height/2 - 32)
    }
    
}


//
//  IdentifyViewController.swift
//
//
//  Created by Wenzheng Du on 8/5/20.
//
import UIKit
import AVFoundation


public class IdentifyViewController: UIViewController {
    
    var useFrontCamera: Bool = true
    var cameraPreviewView: CameraPreviewView?
    
    public convenience init(useFrontCamera: Bool) {
        self.init()
        self.useFrontCamera = useFrontCamera
    }
    
    public override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        self.view = view
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        let cameraPreviewView = CameraPreviewView(frame: UIScreen.main.bounds)
        cameraPreviewView.backgroundColor = .black
        cameraPreviewView.setup(useFrontCamera: useFrontCamera)
        cameraPreviewView.translatesAutoresizingMaskIntoConstraints = false
        cameraPreviewView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.cameraPreviewView = cameraPreviewView
        self.view.addSubview(cameraPreviewView)
    }
    
    public override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        cameraPreviewView?.updateOrientation()
    }
    
}

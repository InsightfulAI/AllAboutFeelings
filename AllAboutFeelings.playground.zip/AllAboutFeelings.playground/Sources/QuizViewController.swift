
//
//  IdentifyViewController.swift
//
//
//  Created by Wenzheng Du on 8/5/20.
//
import UIKit


public class QuizViewController: UIViewController {
    
    private let fileNames = ["AngryFace.jpg", "ScaredFace.jpg", "HappyFace.jpg", "NeutralFace.jpg", "SadFace.jpg", "SurprisedFace.jpg"]
    private let emotions = ["Angry", "Scared", "Happy", "Neutral", "Sad", "Surprised"]
   
    private var stackView: UIStackView!
    private var imageView: UIImageView!
    private var text: UILabel!
    private var buttonBar: UIStackView!
    
    private var numChoices: Int = 6
    
    private var currentAnswer: String = ""
    
    public convenience init(numChoices: Int) {
        self.init()
        self.numChoices = numChoices
        if self.numChoices > 6 {
            self.numChoices = 6
        } else if self.numChoices < 1 {
            self.numChoices = 1
        }
    }
    
    public override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        self.view = view
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    public override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.stackView.frame = self.view.frame.insetBy(dx: 16.0, dy: 16.0)
    }
    
    private func setupViews() {
        let stackView = UIStackView()
        stackView.frame = self.view.frame.insetBy(dx: 16.0, dy: 16.0)
        stackView.alignment = .fill
        stackView.axis = .vertical
        stackView.distribution = .fill
        stackView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.stackView = stackView
        self.view.addSubview(stackView)
        let imageView = UIImageView()
        imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        imageView.contentMode = .scaleAspectFit
        imageView.autoresizingMask = [.flexibleWidth]
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        imageView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        self.imageView = imageView
        stackView.addArrangedSubview(imageView)
        let textView = UILabel()
        textView.frame = CGRect(x: 0, y: 300, width: 300, height: 75)
        textView.font = textView.font.withSize(24)
        textView.text = "Select the correct option"
        textView.autoresizingMask = [.flexibleWidth]
        textView.textAlignment = .center
        textView.textColor = .black
        textView.setContentCompressionResistancePriority(.required, for: .vertical)
        self.text = textView
        stackView.addArrangedSubview(textView)
        let buttonBar = UIStackView()
        buttonBar.frame = CGRect(x: 0, y: 400, width: 300, height: 150)
        buttonBar.axis = .horizontal
        buttonBar.alignment = .fill
        buttonBar.distribution = .fillEqually
        buttonBar.setContentCompressionResistancePriority(.required, for: .vertical)
        self.buttonBar = buttonBar
        stackView.addArrangedSubview(buttonBar)
        startQuiz()
    }
    
    private func startQuiz() {
        for view: UIView in buttonBar.arrangedSubviews {
            view.removeFromSuperview()
        }
        let correctAnswer = emotions.randomElement()!
        currentAnswer = correctAnswer
        let correctIndex = emotions.firstIndex(of: correctAnswer)!
        imageView.image = UIImage(named: fileNames[correctIndex])
        var emotionsCopy = emotions
        var choices: [String] = []
        // Adds the correct choice
        emotionsCopy.remove(at: correctIndex)
        choices.append(correctAnswer)
        emotionsCopy.shuffle()
        for i in 0..<(numChoices-1) {
            choices.append(emotionsCopy[i])
        }
        choices = choices.shuffled()
        for choice: String in choices {
            buttonBar.addArrangedSubview(getButton(label: choice))
        }
    }
    
    private func getButton(label: String) -> UIButton {
        let button = UIButton(type: .system)
        button.frame = CGRect(x: 0, y: 0, width: 100, height: 75)
        button.setTitle(label, for: .normal)
        button.titleLabel!.font = button.titleLabel?.font.withSize(16)
        button.addTarget(self, action: #selector(QuizViewController.buttonPressed(_:)), for: .touchUpInside)
        return button
    }
    
    @objc private func buttonPressed(_ sender: UIButton) {
        if sender.titleLabel?.text == currentAnswer {
            correct()
        } else {
            sender.isUserInteractionEnabled = false
            sender.tintColor = .systemRed
            incorrect()
        }
    }
    
    private func incorrect() {
        text.text = "Incorrect! Try again."
    }
    
    private func correct() {
        text.text = "Correct! The emotion is \(currentAnswer)."
        for view: UIView in buttonBar.arrangedSubviews {
            view.removeFromSuperview()
        }
        let button = UIButton(type: .system)
        button.frame = CGRect(x: 0, y: 0, width: 100, height: 75)
        button.setTitle("Next", for: .normal)
        button.titleLabel!.font = button.titleLabel?.font.withSize(24)
        button.addTarget(self, action: #selector(QuizViewController.startNext(_:)), for: .touchUpInside)
        buttonBar.addArrangedSubview(button)
    }
    
    @objc private func startNext(_ sender: UIButton) {
        startQuiz()
    }
    
}
